﻿
namespace FinalProject
{
    partial class SingUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnSingUp = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.btnclose = new System.Windows.Forms.Button();
            this.lvlSingIn = new System.Windows.Forms.Label();
            this.txtBoxId = new MetroFramework.Controls.MetroTextBox();
            this.txtBoxMail = new MetroFramework.Controls.MetroTextBox();
            this.txtBoxName = new MetroFramework.Controls.MetroTextBox();
            this.txtBoxPass = new MetroFramework.Controls.MetroTextBox();
            this.txtBoxContact = new MetroFramework.Controls.MetroTextBox();
            this.cmbBoxRole = new MetroFramework.Controls.MetroComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(81)))));
            this.label1.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(222)))), ((int)(((byte)(68)))));
            this.label1.Location = new System.Drawing.Point(38, 124);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 37);
            this.label1.TabIndex = 9;
            this.label1.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(81)))));
            this.label2.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(222)))), ((int)(((byte)(68)))));
            this.label2.Location = new System.Drawing.Point(38, 197);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 37);
            this.label2.TabIndex = 19;
            this.label2.Text = "Mail";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(81)))));
            this.label3.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(222)))), ((int)(((byte)(68)))));
            this.label3.Location = new System.Drawing.Point(35, 347);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 37);
            this.label3.TabIndex = 29;
            this.label3.Text = "Password";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(81)))));
            this.label4.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(222)))), ((int)(((byte)(68)))));
            this.label4.Location = new System.Drawing.Point(35, 422);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(186, 37);
            this.label4.TabIndex = 39;
            this.label4.Text = "Contact No.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(81)))));
            this.label5.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(222)))), ((int)(((byte)(68)))));
            this.label5.Location = new System.Drawing.Point(35, 272);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 37);
            this.label5.TabIndex = 49;
            this.label5.Text = "Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(81)))));
            this.label6.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(222)))), ((int)(((byte)(68)))));
            this.label6.Location = new System.Drawing.Point(36, 492);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 37);
            this.label6.TabIndex = 69;
            this.label6.Text = "Role";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(81)))));
            this.label7.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(222)))), ((int)(((byte)(68)))));
            this.label7.Location = new System.Drawing.Point(123, 43);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(461, 55);
            this.label7.TabIndex = 0;
            this.label7.Text = "Create Your Account ";
            // 
            // btnSingUp
            // 
            this.btnSingUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSingUp.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSingUp.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSingUp.Location = new System.Drawing.Point(269, 581);
            this.btnSingUp.Margin = new System.Windows.Forms.Padding(4);
            this.btnSingUp.Name = "btnSingUp";
            this.btnSingUp.Size = new System.Drawing.Size(157, 50);
            this.btnSingUp.TabIndex = 7;
            this.btnSingUp.Text = "Sing Up";
            this.btnSingUp.UseVisualStyleBackColor = true;
            this.btnSingUp.Click += new System.EventHandler(this.btnSingUp_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(81)))));
            this.label8.Font = new System.Drawing.Font("Yu Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(222)))), ((int)(((byte)(68)))));
            this.label8.Location = new System.Drawing.Point(51, 644);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(400, 36);
            this.label8.TabIndex = 149;
            this.label8.Text = "All Ready Have An Account !";
            // 
            // btnclose
            // 
            this.btnclose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(108)))), ((int)(((byte)(126)))));
            this.btnclose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnclose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(108)))), ((int)(((byte)(126)))));
            this.btnclose.FlatAppearance.BorderSize = 0;
            this.btnclose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(108)))), ((int)(((byte)(126)))));
            this.btnclose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(73)))), ((int)(((byte)(96)))));
            this.btnclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclose.Font = new System.Drawing.Font("Calibri Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclose.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnclose.Location = new System.Drawing.Point(607, 9);
            this.btnclose.Margin = new System.Windows.Forms.Padding(0);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(63, 49);
            this.btnclose.TabIndex = 159;
            this.btnclose.Text = "X";
            this.btnclose.UseVisualStyleBackColor = false;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // lvlSingIn
            // 
            this.lvlSingIn.AutoSize = true;
            this.lvlSingIn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lvlSingIn.Font = new System.Drawing.Font("Yu Gothic", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvlSingIn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(196)))), ((int)(((byte)(158)))));
            this.lvlSingIn.Location = new System.Drawing.Point(459, 638);
            this.lvlSingIn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lvlSingIn.Name = "lvlSingIn";
            this.lvlSingIn.Size = new System.Drawing.Size(144, 44);
            this.lvlSingIn.TabIndex = 8;
            this.lvlSingIn.Text = " Sing in";
            this.lvlSingIn.Click += new System.EventHandler(this.lvlSingIn_Click);
            // 
            // txtBoxId
            // 
            this.txtBoxId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(108)))), ((int)(((byte)(126)))));
            // 
            // 
            // 
            this.txtBoxId.CustomButton.Image = null;
            this.txtBoxId.CustomButton.Location = new System.Drawing.Point(333, 1);
            this.txtBoxId.CustomButton.Name = "";
            this.txtBoxId.CustomButton.Size = new System.Drawing.Size(35, 35);
            this.txtBoxId.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBoxId.CustomButton.TabIndex = 1;
            this.txtBoxId.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBoxId.CustomButton.UseSelectable = true;
            this.txtBoxId.CustomButton.Visible = false;
            this.txtBoxId.Lines = new string[0];
            this.txtBoxId.Location = new System.Drawing.Point(260, 124);
            this.txtBoxId.MaxLength = 32767;
            this.txtBoxId.Name = "txtBoxId";
            this.txtBoxId.PasswordChar = '\0';
            this.txtBoxId.ReadOnly = true;
            this.txtBoxId.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBoxId.SelectedText = "";
            this.txtBoxId.SelectionLength = 0;
            this.txtBoxId.SelectionStart = 0;
            this.txtBoxId.ShortcutsEnabled = true;
            this.txtBoxId.Size = new System.Drawing.Size(369, 37);
            this.txtBoxId.TabIndex = 1;
            this.txtBoxId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBoxId.UseSelectable = true;
            this.txtBoxId.WaterMarkColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtBoxId.WaterMarkFont = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // txtBoxMail
            // 
            // 
            // 
            // 
            this.txtBoxMail.CustomButton.Image = null;
            this.txtBoxMail.CustomButton.Location = new System.Drawing.Point(333, 1);
            this.txtBoxMail.CustomButton.Name = "";
            this.txtBoxMail.CustomButton.Size = new System.Drawing.Size(35, 35);
            this.txtBoxMail.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBoxMail.CustomButton.TabIndex = 1;
            this.txtBoxMail.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBoxMail.CustomButton.UseSelectable = true;
            this.txtBoxMail.CustomButton.Visible = false;
            this.txtBoxMail.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtBoxMail.Lines = new string[0];
            this.txtBoxMail.Location = new System.Drawing.Point(260, 197);
            this.txtBoxMail.MaxLength = 32767;
            this.txtBoxMail.Name = "txtBoxMail";
            this.txtBoxMail.PasswordChar = '\0';
            this.txtBoxMail.PromptText = "Enter Your Mail";
            this.txtBoxMail.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBoxMail.SelectedText = "";
            this.txtBoxMail.SelectionLength = 0;
            this.txtBoxMail.SelectionStart = 0;
            this.txtBoxMail.ShortcutsEnabled = true;
            this.txtBoxMail.Size = new System.Drawing.Size(369, 37);
            this.txtBoxMail.TabIndex = 2;
            this.txtBoxMail.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBoxMail.UseSelectable = true;
            this.txtBoxMail.WaterMark = "Enter Your Mail";
            this.txtBoxMail.WaterMarkColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtBoxMail.WaterMarkFont = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // txtBoxName
            // 
            // 
            // 
            // 
            this.txtBoxName.CustomButton.Image = null;
            this.txtBoxName.CustomButton.Location = new System.Drawing.Point(333, 1);
            this.txtBoxName.CustomButton.Name = "";
            this.txtBoxName.CustomButton.Size = new System.Drawing.Size(35, 35);
            this.txtBoxName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBoxName.CustomButton.TabIndex = 1;
            this.txtBoxName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBoxName.CustomButton.UseSelectable = true;
            this.txtBoxName.CustomButton.Visible = false;
            this.txtBoxName.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtBoxName.Lines = new string[0];
            this.txtBoxName.Location = new System.Drawing.Point(260, 272);
            this.txtBoxName.MaxLength = 32767;
            this.txtBoxName.Name = "txtBoxName";
            this.txtBoxName.PasswordChar = '\0';
            this.txtBoxName.PromptText = "Enter Your Name";
            this.txtBoxName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBoxName.SelectedText = "";
            this.txtBoxName.SelectionLength = 0;
            this.txtBoxName.SelectionStart = 0;
            this.txtBoxName.ShortcutsEnabled = true;
            this.txtBoxName.Size = new System.Drawing.Size(369, 37);
            this.txtBoxName.TabIndex = 4;
            this.txtBoxName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBoxName.UseSelectable = true;
            this.txtBoxName.WaterMark = "Enter Your Name";
            this.txtBoxName.WaterMarkColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtBoxName.WaterMarkFont = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // txtBoxPass
            // 
            // 
            // 
            // 
            this.txtBoxPass.CustomButton.Image = null;
            this.txtBoxPass.CustomButton.Location = new System.Drawing.Point(333, 1);
            this.txtBoxPass.CustomButton.Name = "";
            this.txtBoxPass.CustomButton.Size = new System.Drawing.Size(35, 35);
            this.txtBoxPass.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBoxPass.CustomButton.TabIndex = 1;
            this.txtBoxPass.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBoxPass.CustomButton.UseSelectable = true;
            this.txtBoxPass.CustomButton.Visible = false;
            this.txtBoxPass.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtBoxPass.Lines = new string[0];
            this.txtBoxPass.Location = new System.Drawing.Point(260, 347);
            this.txtBoxPass.MaxLength = 32767;
            this.txtBoxPass.Name = "txtBoxPass";
            this.txtBoxPass.PasswordChar = '●';
            this.txtBoxPass.PromptText = "Enter Your Password";
            this.txtBoxPass.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBoxPass.SelectedText = "";
            this.txtBoxPass.SelectionLength = 0;
            this.txtBoxPass.SelectionStart = 0;
            this.txtBoxPass.ShortcutsEnabled = true;
            this.txtBoxPass.Size = new System.Drawing.Size(369, 37);
            this.txtBoxPass.TabIndex = 5;
            this.txtBoxPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBoxPass.UseSelectable = true;
            this.txtBoxPass.UseSystemPasswordChar = true;
            this.txtBoxPass.WaterMark = "Enter Your Password";
            this.txtBoxPass.WaterMarkColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtBoxPass.WaterMarkFont = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // txtBoxContact
            // 
            // 
            // 
            // 
            this.txtBoxContact.CustomButton.Image = null;
            this.txtBoxContact.CustomButton.Location = new System.Drawing.Point(333, 1);
            this.txtBoxContact.CustomButton.Name = "";
            this.txtBoxContact.CustomButton.Size = new System.Drawing.Size(35, 35);
            this.txtBoxContact.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBoxContact.CustomButton.TabIndex = 1;
            this.txtBoxContact.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBoxContact.CustomButton.UseSelectable = true;
            this.txtBoxContact.CustomButton.Visible = false;
            this.txtBoxContact.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtBoxContact.Lines = new string[0];
            this.txtBoxContact.Location = new System.Drawing.Point(260, 422);
            this.txtBoxContact.MaxLength = 32767;
            this.txtBoxContact.Name = "txtBoxContact";
            this.txtBoxContact.PasswordChar = '\0';
            this.txtBoxContact.PromptText = "Enter Your Contact Number";
            this.txtBoxContact.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBoxContact.SelectedText = "";
            this.txtBoxContact.SelectionLength = 0;
            this.txtBoxContact.SelectionStart = 0;
            this.txtBoxContact.ShortcutsEnabled = true;
            this.txtBoxContact.Size = new System.Drawing.Size(369, 37);
            this.txtBoxContact.TabIndex = 6;
            this.txtBoxContact.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBoxContact.UseSelectable = true;
            this.txtBoxContact.WaterMark = "Enter Your Contact Number";
            this.txtBoxContact.WaterMarkColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtBoxContact.WaterMarkFont = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // cmbBoxRole
            // 
            this.cmbBoxRole.FormattingEnabled = true;
            this.cmbBoxRole.ItemHeight = 24;
            this.cmbBoxRole.Items.AddRange(new object[] {
            "Seller",
            "Purchase Manager"});
            this.cmbBoxRole.Location = new System.Drawing.Point(260, 499);
            this.cmbBoxRole.Name = "cmbBoxRole";
            this.cmbBoxRole.Size = new System.Drawing.Size(369, 30);
            this.cmbBoxRole.TabIndex = 3;
            this.cmbBoxRole.UseSelectable = true;
            // 
            // SingUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(108)))), ((int)(((byte)(126)))));
            this.ClientSize = new System.Drawing.Size(679, 705);
            this.Controls.Add(this.cmbBoxRole);
            this.Controls.Add(this.txtBoxContact);
            this.Controls.Add(this.txtBoxPass);
            this.Controls.Add(this.txtBoxName);
            this.Controls.Add(this.txtBoxMail);
            this.Controls.Add(this.txtBoxId);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnSingUp);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lvlSingIn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "SingUp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "singup";
            this.Load += new System.EventHandler(this.SingUp_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnSingUp;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.Label lvlSingIn;
        private MetroFramework.Controls.MetroTextBox txtBoxId;
        private MetroFramework.Controls.MetroTextBox txtBoxMail;
        private MetroFramework.Controls.MetroTextBox txtBoxName;
        private MetroFramework.Controls.MetroTextBox txtBoxPass;
        private MetroFramework.Controls.MetroTextBox txtBoxContact;
        private MetroFramework.Controls.MetroComboBox cmbBoxRole;
    }
}